#!/usr/bin/env python3
import json, os, glob
import pandas as pd
from jinja2 import Template

report_dir = "/tmp/compliance_report"
data_files = glob.glob(os.path.join(report_dir, "*.json"))

rows = []
for f in data_files:
    with open(f) as infile:
        rows.append(json.load(infile))

df = pd.DataFrame(rows)
df = df[["ip", "name", "os", "kernel", "uptime", "compliance"]]

# Excel Report
excel_file = os.path.join(report_dir, "compliance_report.xlsx")
df.to_excel(excel_file, index=False)

# HTML Report
with open(os.path.join(report_dir, "report_template.html.j2")) as tpl_file:
    template = Template(tpl_file.read())
    html_out = template.render(servers=rows)

with open(os.path.join(report_dir, "report.html"), "w") as out_html:
    out_html.write(html_out)
